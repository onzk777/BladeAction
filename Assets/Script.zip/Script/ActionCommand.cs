using UnityEngine;
public enum ActionCommand
{
    Attack_HorizontalSlash,
    Attack_VerticalSlash,
    Thrust,
    Defend,
    SecretArt // ����
}
